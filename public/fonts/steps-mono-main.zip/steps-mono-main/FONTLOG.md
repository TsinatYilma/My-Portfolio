FONTLOG for Demo
-------------------

This file provides detailed information on the Demo font software.
This information should be distributed along with the Demo fonts
and any derivative works.


Basic Font Information
--------------------------

This font was created for the french magazine étapes: in order to demontrate
a collaborative work around a typeface.


Information for Contributors
------------------------------

Steps Mono is released under the OFL 1.1 - http://scripts.sil.org/OFL

For information on what you're allowed to change or modify, consult the
OFL-1.1.txt and OFL-FAQ.txt files. The OFL-FAQ also gives a very general
rationale and various recommendations regarding why you would want to
contribute to the project or make your own version of the font.


ChangeLog
----------

When you make modifications, be sure to add a description of your changes,
following the format of the other entries, to the start of this section.

12 Mars 2015 (Raphaël Bastide) Steps-mono, v0.1
- Added question mark /?

12 April 2014 (Raphaël Bastide) Steps-mono, v0.1
- Changed name to "Steps-mono"

12 April 2014 (Raphaël Bastide) Steps-mono, v0.2
- Fat accents

Acknowledgements
-------------------------

When you make modifications, be sure to add your name (N), email (E),
web-address (W) and description (D). This list is sorted by last name in
alphabetical order.

N: Raphaël Bastide
E: bonjour@raphaelbastide.com
W: http://raphaelbastide.com
D: Designer
